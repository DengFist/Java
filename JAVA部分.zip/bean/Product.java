package bean;

public class Product {
	public String name;
	public int id;
	public double price;
	public String introduction;
	
	 public int getId() {
	        return id;
	    }
	    public void setId(int id) {
	        this.id = id;
	    }
	    public String getName() {
	        return name;
	    }
	    public void setName(String name) {
	        this.name = name;
	    }
	    public double getPrice() {
	        return price;
	    }
	    public void setPrice(double price) {
	        this.price = price;
	    }
	    public String getIntroduction() {
	        return introduction;
	    }
	    public void setIntroduction(String introduction) {
	        this.introduction = introduction;
	    }
}
