package servlet;
 
import java.io.IOException;
 
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import bean.Product;
import dao.ProductDAO;
 
public class ProductEditServlet extends HttpServlet {
 
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
 
        int id = Integer.parseInt(request.getParameter("id"));
 
       Product hero = new ProductDAO().get(id);
 
        StringBuffer format = new StringBuffer();
        response.setContentType("text/html; charset=UTF-8");
 
        format.append("<!DOCTYPE html>");
 
        format.append("<form action='updateProduct' method='post'>");
        format.append("���� �� <input type='text' name='name' value='%s' > <br>");
        format.append("�۸� �� <input type='text' name='price'  value='%f' > <br>");
        format.append("������ <input type='text' name='introduction'  value='%s' > <br>");
        format.append("<input type='hidden' name='id' value='%d'>");
        format.append("<input type='submit' value='����'>");
        format.append("</form>");
 
        String html = String.format(format.toString(), hero.getName(), hero.getPrice(), hero.getIntroduction(), hero.getId());
 
        response.getWriter().write(html);
 
    }
}