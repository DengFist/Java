package servlet;

 
import java.io.IOException;
import java.util.List;
 
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import bean.Product;
import dao.ProductDAO;


public class DengProductListServlet extends HttpServlet {
 
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
         
        List<Product> products = new ProductDAO().list();
 
        StringBuffer sb = new StringBuffer();
        sb.append("<table align='center' border='1' cellspacing='0'>\r\n");
        sb.append("<tr><td>id</td><td>name</td><td>price</td><td>introduction</td><td>edit</td><td>delete</td></tr>\r\n");
 
        String trFormat = "<tr><td>%d</td><td>%s</td><td>%f</td><td>%s</td>x<td><a href='editProduct?id=%d'>edit</a></td><td><a href='deleteProduct?id=%d'>delete</a></td></tr>\r\n";
 
        for (Product product : products) {
            String tr = String.format(trFormat, product.getId(), product.getName(), product.getPrice(), product.getIntroduction(),product.getId(),product.getId());
            sb.append(tr);
        }
 
        sb.append("</table>");
 
        response.getWriter().write(sb.toString());
    }
}