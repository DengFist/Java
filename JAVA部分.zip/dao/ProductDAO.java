package dao;

  
import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
 
import bean.Product;
  
public class ProductDAO {
  
    public ProductDAO() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
  
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/how2java?characterEncoding=UTF-8", "root",
                "admin");
    }
  
    public int getTotal() {
        int total = 0;
        try (Connection c = getConnection(); Statement s = c.createStatement();) {
  
            String sql = "select count(*) from product";
            	
            ResultSet rs = s.executeQuery(sql);
            while (rs.next()) {
                total = rs.getInt(1);
            }
  
            System.out.println("total:" + total);
  
        } catch (SQLException e) {
  
            e.printStackTrace();
        }
        return total;
    }
  
    public void add(Product product) {
  
        String sql = "insert into product values(null,?,?,?)";
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
  
            ps.setString(1, product.name);
            ps.setDouble(2, product.price);
            ps.setString(3, product.introduction);
  
            ps.execute();
  
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                product.id = id;
            }
        } catch (SQLException e) {
  
            e.printStackTrace();
        }
    }
  
    public void update(Product product) {
  
        String sql = "update product set name= ?, price = ? , introduction = ? where id = ?";
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
  
            ps.setString(1, product.name);
            ps.setDouble(2, product.price);
            ps.setString(3, product.introduction);
            ps.setInt(4, product.id);
  
            ps.execute();
  
        } catch (SQLException e) {
  
            e.printStackTrace();
        }
  
    }
  
    public void delete(int id) {
  
        try (Connection c = getConnection(); Statement s = c.createStatement();) {
  
            String sql = "delete from product where id = " + id;
  
            s.execute(sql);
  
        } catch (SQLException e) {
  
            e.printStackTrace();
        }
    }
  
    public Product get(int id) {
        Product product = null;
  
        try (Connection c = getConnection(); Statement s = c.createStatement();) {
  
            String sql = "select * from product where id = " + id;
  
            ResultSet rs = s.executeQuery(sql);
  
            if (rs.next()) {
            	product = new Product();
                String name = rs.getString(2);
                double price = rs.getDouble("price");
                String introduction = rs.getString(4);
                product.name = name;
                product.price = price;
                product.introduction = introduction;
                product.id = id;
            }
  
        } catch (SQLException e) {
  
            e.printStackTrace();
        }
        return product;
    }
  
    public List<Product> list() {
        return list(0, Short.MAX_VALUE);
    }
  
    public List<Product> list(int start, int count) {
        List<Product> products = new ArrayList<Product>();
  
        String sql = "select * from product order by id desc limit ?,? ";
  
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
  
            ps.setInt(1, start);
            ps.setInt(2, count);
  
            ResultSet rs = ps.executeQuery();
  
            while (rs.next()) {
                Product product = new Product();
                int id = rs.getInt(1);
                String name = rs.getString(2);
                double price = rs.getDouble("price");
                String introduction= rs.getString(4);
                product.id = id;
                product.name = name;
                product.price = price;
                product.introduction = introduction;
                products.add(product);
            }
        } catch (SQLException e) {
  
            e.printStackTrace();
        }
        return products;
    }
  
}